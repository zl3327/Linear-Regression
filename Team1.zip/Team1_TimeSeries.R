# LR Final Project 
# Group 1
# Professor Lee

# Importing  libraries
library(plyr)
library(stats)
library(ggplot2)
library(data.table)
library(stats)
library(caret)
library(lmtest)
library(car)
library(leaps)
library(glmnet)
library(dplyr)
library(readr)
library(car)
library(tseries)

# Data Processing
##################################
#Set WD
setwd("~/Desktop/LR FINAL PROJ")

# Read the dataset
df <- read_csv("CO2_USA.csv")

# Drop constants and select relevant columns
df_cleaned <- df %>% select(Year, CO2_emission_pre, Density, real_GDP, Temperature, CO2_emission)

# Assign independent variables (assuming these are your predictors)
X <- select(df_cleaned, CO2_emission_pre, Density, real_GDP, Temperature)

# Standardize via Z-score
X_scaled <- scale(X)

# Add a constant column of 1.0 to X
X_scaled <- cbind(const = 1, X_scaled)

# Recombine year with X
X <- cbind(select(df_cleaned, Year), X_scaled)

# Assign dependent variable
y <- df_cleaned$CO2_emission

# OLS
##################################

# Run the OLS regression model with CO2_emission as the dependent variable
ols_model <- lm(y ~ . - 1, data = X) # The -1 omits the automatic intercept
summary(ols_model)


# WLS
##################################

# Add weights for WLS model - 1/real_GDP
weights <- 1 / df_cleaned$real_GDP

# Run the WLS regression model
wls_model <- lm(y ~ . - 1, data = X, weights = weights) # The -1 omits the automatic intercept
summary(wls_model)

# Calculate VIF
vif_values <- vif(ols_model)

# Convert to a data frame for plotting
vif_df <- as.data.frame(vif_values)

# Print VIF values
print(vif_values)

# Calculate the predicted from OLS and WLS models
ols_pred <- predict(ols_model, X)
wls_pred <- predict(wls_model, X)

# Create a data frame for plotting
plot_df <- data.frame(Year = X$Year, Actual = y, OLS_Predicted = ols_pred, WLS_Predicted = wls_pred)

# Plot for OLS  Vs Actual
ggplot(plot_df, aes(x = Year)) +
  geom_point(aes(y = Actual), color = 'blue', alpha = 0.6, size = 2, shape = 1) +
  geom_line(aes(y = OLS_Predicted, group = 1), color = 'red') +
  labs(title = "OLS Model - Actual vs Predicted CO2 Emissions",
       x = "Year",
       y = "CO2 Emissions") +
  theme_minimal() +
  theme(legend.position = "bottom") +
  guides(color = guide_legend(title = "Legend"))

# Plot  WLS Vs Actual
ggplot(plot_df, aes(x = Year)) +
  geom_point(aes(y = Actual), color = 'blue', alpha = 0.6, size = 2, shape = 1) +
  geom_line(aes(y = WLS_Predicted, group = 1), color = 'green') +
  labs(title = "WLS Model - Actual vs Predicted CO2 Emissions",
       x = "Year",
       y = "CO2 Emissions") +
  theme_minimal() +
  theme(legend.position = "bottom") +
  guides(color = guide_legend(title = "Legend"))

# Calculate residuals for the OLS model
ols_residuals <- y - ols_pred

# Plotting residuals for OLS model
ggplot(plot_df, aes(x = OLS_Predicted, y = ols_residuals)) +
  geom_point(color = 'blue', alpha = 0.6) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
  labs(title = "Residuals vs Predicted Values (OLS Model)",
       x = "Predicted Values",
       y = "Residuals") +
  theme_minimal()

# Calculate residuals for the WLS model
wls_residuals <- y - wls_pred

# Plotting residuals for WLS model
ggplot(plot_df, aes(x = WLS_Predicted, y = wls_residuals)) +
  geom_point(color = 'green', alpha = 0.6) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
  labs(title = "Residuals vs Predicted Values (WLS Model)",
       x = "Predicted Values",
       y = "Residuals") +
  theme_minimal()

# ELastic
##################################

# Prepare matrix for elastic net
X_matrix <- model.matrix(~ ., data = X)[, -1]  # Convert to matrix and remove intercept

# Fit Elastic Net model and define parameters
set.seed(0)  # For reproducibility
elastic_net_model <- cv.glmnet(X_matrix, y, alpha = 0.1, l1_ratio = 0.9, type.measure = "mse")

# Extract the best lambda (penalty parameter)
best_lambda <- elastic_net_model$lambda.min

# Coefficients
coef(elastic_net_model, s = best_lambda)

# Making predictions
predictions <- predict(elastic_net_model, newx = X_matrix, s = best_lambda)

# Calculate residuals for the Elastic Net model
en_residuals <- y - predictions

# Diagnostic Tests
##################################

#OLS

# Jarque-Bera test OLS
jarque.bera.test(ols_residuals)
# Jarque-Bera test WLS
jarque.bera.test(wls_residuals)
# Jarque-Bera test Elastic Net
#jarque.bera.test(elastic_net_model)

# Breusch-Pagan test
bptest(ols_model)
# Breusch-Pagan test
bptest(wls_model)
# Breusch-Pagan test
# Calculate squared residuals
squared_en_residuals <- en_residuals^2
# Fit an specific regression model
en_bp_model <- lm(squared_en_residuals ~ ., data = X_noC)
# Perform the Breusch-Pagan test
bptest(en_bp_model)

# Durbin-Watson test
durbinWatsonTest(wls_model)
# Durbin-Watson test
durbinWatsonTest(ols_model)
# Durbin-Watson test
#durbinWatsonTest(elastic_net_model)

# Calculate VIF
vif_values <- vif(ols_model)
# Convert to a data frame for plotting
vif_df <- as.data.frame(vif_values)
# Print VIF values
print(vif_values)

#QQ Plot
# Calculate Elastic Net residuals
en_residuals <- y - predictions

# Standard normal quantiles
std_norm_quantiles <- qqnorm(ols_residuals, plot.it = FALSE)$x

# Create the Q-Q plot for OLS residuals
qqplot(std_norm_quantiles, ols_residuals, col = "blue", main = "Combined Q-Q Plot", xlab = "Theoretical Quantiles", ylab = "Sample Quantiles", xlim = range(std_norm_quantiles), ylim = range(c(ols_residuals, wls_residuals, en_residuals)))

# Add WLS residuals to the plot
points(std_norm_quantiles, wls_residuals, col = "red")

# Add Elastic Net residuals to the plot
points(std_norm_quantiles, en_residuals, col = "green")

# Add a legend
legend("topright", legend = c("OLS", "WLS", "Elastic Net"), col = c("blue", "red", "green"), pch = 1)


